﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR_5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            LstPrice.Items.Clear();
            LstPrice.Items.Add($"{DateTime.Now}");
            LstPrice.Items.Add("Заказ:");
            int a = 0, b = 0, c = 0, d = 0;
            if (ChChburgir.IsChecked == true)
            {
                a = int.Parse(TextChburgir.Text) * 80;
                LstPrice.Items.Add($"Чизбургер {TextChburgir.Text}* 90руб = {a}");
            }
            if (ChGamburgir.IsChecked == true)
            {
                b = int.Parse(TextGamburgir.Text) * 120;
                LstPrice.Items.Add($"Гамбургер {TextGamburgir.Text}* 140руб = {b}");
            }
            if (ChSosaSola.IsChecked == true)
            {
                c = int.Parse(TextSosaSola.Text) * 62;
                LstPrice.Items.Add($"Кока-кола {TextSosaSola.Text}* 65руб = {c}");
            }
            if (ChNugets.IsChecked == true)
            {
                d = int.Parse(TextNugets.Text) * 90;
                LstPrice.Items.Add($"Нагетсы {TextNugets.Text}* 99руб = {d}");
            }
            LstPrice.Items.Add("---------------");
            LstPrice.Items.Add($"К оплате: {a + b + c + d}");
        }
    }
}
