﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Count_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double a = double.Parse(FirstNum.Text);
                double b = double.Parse(TwoNum.Text);
                Sum.Text = Convert.ToString(a + b);
                double a2 = double.Parse(FirstNum.Text);
                double b2 = double.Parse(TwoNum.Text);
                sub.Text = Convert.ToString(a2 - b2);
                double a3 = double.Parse(FirstNum.Text);
                double b3 = double.Parse(TwoNum.Text);
                mul.Text = Convert.ToString(a3 * b3);
                double a4 = double.Parse(FirstNum.Text);
                double b4 = double.Parse(TwoNum.Text);
                div.Text = Convert.ToString(a4 / b4);
            }
            catch
            {
                MessageBox.Show("Пустые значения.Введите данные");
            }
        }
    }
}
